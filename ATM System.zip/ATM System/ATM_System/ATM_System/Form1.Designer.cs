﻿namespace ATM_System
{
    partial class mainscreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wc = new System.Windows.Forms.Button();
            this.checkb = new System.Windows.Forms.Button();
            this.sendm = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.x = new System.Windows.Forms.Button();
            this.learnm = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // wc
            // 
            this.wc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wc.Location = new System.Drawing.Point(12, 172);
            this.wc.Name = "wc";
            this.wc.Size = new System.Drawing.Size(216, 106);
            this.wc.TabIndex = 0;
            this.wc.Text = "Withdraw Cash";
            this.wc.UseVisualStyleBackColor = true;
            this.wc.Click += new System.EventHandler(this.wc_Click);
            // 
            // checkb
            // 
            this.checkb.BackColor = System.Drawing.Color.Transparent;
            this.checkb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkb.Location = new System.Drawing.Point(572, 172);
            this.checkb.Name = "checkb";
            this.checkb.Size = new System.Drawing.Size(216, 106);
            this.checkb.TabIndex = 0;
            this.checkb.Text = "Check Balance";
            this.checkb.UseVisualStyleBackColor = false;
            this.checkb.Click += new System.EventHandler(this.button2_Click);
            // 
            // sendm
            // 
            this.sendm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendm.Location = new System.Drawing.Point(12, 309);
            this.sendm.Name = "sendm";
            this.sendm.Size = new System.Drawing.Size(216, 106);
            this.sendm.TabIndex = 0;
            this.sendm.Text = "Send Money";
            this.sendm.UseVisualStyleBackColor = true;
            this.sendm.Click += new System.EventHandler(this.sendm_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(237, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 32);
            this.label1.TabIndex = 5;
            this.label1.Text = "ATM Machine System";
            // 
            // x
            // 
            this.x.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x.Location = new System.Drawing.Point(748, 13);
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(39, 41);
            this.x.TabIndex = 6;
            this.x.Text = "X";
            this.x.UseVisualStyleBackColor = true;
            this.x.Click += new System.EventHandler(this.x_Click);
            // 
            // learnm
            // 
            this.learnm.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.learnm.Location = new System.Drawing.Point(572, 309);
            this.learnm.Name = "learnm";
            this.learnm.Size = new System.Drawing.Size(216, 106);
            this.learnm.TabIndex = 0;
            this.learnm.Text = "Learn More";
            this.learnm.UseVisualStyleBackColor = true;
            this.learnm.Click += new System.EventHandler(this.button1_Click);
            // 
            // mainscreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.learnm);
            this.Controls.Add(this.x);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sendm);
            this.Controls.Add(this.checkb);
            this.Controls.Add(this.wc);
            this.Name = "mainscreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ATM Machine System";
            this.Load += new System.EventHandler(this.mainscreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button checkb;
        private System.Windows.Forms.Button sendm;
        public System.Windows.Forms.Button wc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button x;
        private System.Windows.Forms.Button learnm;
    }
}

