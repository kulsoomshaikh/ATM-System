﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_System
{
    public partial class mainscreen : Form
    {
        public mainscreen()
        {
            InitializeComponent();
        }
      
        public double abalance = 40000;
       
        private void mainscreen_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            checkbalance cb = new checkbalance();
            cb.Show();
        }

        private void learnm_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void sendm_Click(object sender, EventArgs e)
        {
            this.Hide();
            sendmoney sm = new sendmoney();
            sm.label8.Hide();
            sm.label10.Hide();
            sm.label6.Hide();
            sm.label7.Hide();
            sm.Show();
            
        }

        private void wc_Click(object sender, EventArgs e)
        {
            this.Hide();
            withc wc = new withc();
            wc.wclabel.Hide();
            wc.textBox1.Hide();
            wc.proc.Hide();
            wc.label1.Hide();
            wc.label2.Hide();
            wc.Show();
        }

        private void x_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void payb_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            learnmore lm = new learnmore();
            lm.Show();
        }
    }
}
