﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_System
{
    public partial class checkbalance : Form
    {
        mainscreen ms = new mainscreen();
        public checkbalance()
        {
            InitializeComponent();
        }
        private void checkbalance_Load(object sender, EventArgs e)
        {

        }

        private void btms_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainscreen ms = new mainscreen();
            ms.Show();
        }
        int[] pinnn = new int[4] { 1, 2, 3, 4 };
        string pinn1, pinn2, pinn3, pinn4;
        private void pin1_TextChanged(object sender, EventArgs e)
        {
            pinn1 = pin1.Text;
            int s = pin1.Text.Length;
            if (s == 1)
                pin2.Focus();
        }
        
        private void pin2_TextChanged_1(object sender, EventArgs e)
        {
            pinn2 = pin2.Text;
            int s = pin2.Text.Length;
            if (s == 1)
                pin3.Focus();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ms.Show();
        }

        private void pin4_TextChanged_1(object sender, EventArgs e)
        {
            pinn4 = pin4.Text;
            int s = pin4.Text.Length;
            if (s == 1)
                button1.Focus();
        }

        private void pin3_TextChanged_1(object sender, EventArgs e)
        {
            pinn3 = pin3.Text;
            int s = pin3.Text.Length;
            if (s == 1)
                pin4.Focus();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                    if (Convert.ToInt32(pinn1) == pinnn[0] && Convert.ToInt32(pinn2) == pinnn[1] && Convert.ToInt32(pinn3) == pinnn[2] && Convert.ToInt32(pinn4) == pinnn[3])
                    {
                        label4.Hide();
                        label3.Text ="Your Balance is PKR" + Convert.ToString(ms.abalance); 
                    }
                else
                {
                    label3.Text = "Wrong Pin";
                }
            }
            catch
            {
                label4.Text = "Please Enter a Valid Pin";
            }
        }
    }
}
