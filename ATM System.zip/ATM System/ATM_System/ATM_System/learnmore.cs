﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_System
{
    public partial class learnmore : Form
    {
        public learnmore()
        {
            InitializeComponent();
        }

        private void backfromlm_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainscreen main = new mainscreen();
            main.Show();
        }

        private void x_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
