﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_System
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] pin = new int[4] {1,2,3,4};
            if(Convert.ToInt32(pin1.Text)==pin[0] && Convert.ToInt32(pin2.Text) == pin[1] && Convert.ToInt32(pin3.Text) == pin[2] && Convert.ToInt32(pin4.Text) == pin[3])
            {
                mainscreen ms = new mainscreen();
                this.Hide();
                ms.Show();
            }
            else { label3.Text = "Login Failed: Please Enter a Correct Pin"; }

        }

        private void pin3_TextChanged(object sender, EventArgs e)
        {
            int s = pin3.Text.Length;
            if (s == 1)
                pin4.Focus();
        }

        private void pin1_TextChanged(object sender, EventArgs e)
        {
            int s = pin1.Text.Length;
            if (s == 1)
                pin2.Focus();
        }

        private void pin1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void pin2_TextChanged(object sender, EventArgs e)
        {
            int s = pin2.Text.Length;
            if (s == 1)
                pin3.Focus();
        }

        private void pin4_TextChanged(object sender, EventArgs e)
        {
            int s = pin4.Text.Length;
            if (s == 1)
                button1.Focus();
        }

        private void x_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void login_Load(object sender, EventArgs e)
        {

        }
    }
}
