﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_System
{
    public partial class sendmoney : Form
    {
        public sendmoney()
        {
            InitializeComponent();
        }
        mainscreen ms = new mainscreen();
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            int[] pin = new int[4] { 1, 2, 3, 4 };
            if (Convert.ToInt32(pin1.Text) == pin[0] && Convert.ToInt32(pin2.Text) == pin[1] && Convert.ToInt32(pin3.Text) == pin[2] && Convert.ToInt32(pin4.Text) == pin[3])
            {
                label1.Text = "Transfering Funds";
                label7.Hide();
                confirmbox.Hide();

            }
            else
            {
                label7.Text = "Error: Wrong Pin";
                label7.Show();
                timer1.Enabled = false;
            }







            if (a == 85)
            {
                mainscreen ms = new mainscreen();
                if (amm <= ms.abalance)
                {
                    
                }
                else
                {
                    label7.Text = "Error: Insufficient Balance";
                    label7.Show();
                }

            }
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
            
        }

        int amm;
        int raccno;
        private void button1_Click(object sender, EventArgs e)
        {
                if(amm>=0 || raccno >= 0)
                {
                    groupBox1.Hide();
                    groupBox2.Hide();
                    confirmbox.Show();
                label4.Text = "You are sending " + amm;
                    label9.Text = "to Account Number: " + raccno;
                        label11.Text = "Please Enter Your Account Pin to Confirm Transaction";
                }
        }

        private void sendmoney_Load(object sender, EventArgs e)
        {

        }

        private void x_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void pin1_TextChanged(object sender, EventArgs e)
        {
            int s = pin1.Text.Length;
            if (s == 1)
                pin2.Focus();
        }

        private void pin2_TextChanged(object sender, EventArgs e)
        {
            int s = pin2.Text.Length;
            if (s == 1)
                pin3.Focus();
        }

        private void pin3_TextChanged(object sender, EventArgs e)
        {
            int s = pin3.Text.Length;
            if (s == 1)
                pin4.Focus();
        }

        private void pin4_TextChanged(object sender, EventArgs e)
        {
            int s = pin4.Text.Length;
            if (s == 1)
                button2.Focus();
        }

        private void anum_TextChanged(object sender, EventArgs e)
        {
            try
            {
                raccno = Convert.ToInt32(anum.Text);
            }
            catch
            {
                label8.Text = "Please Enter Account Number in Digits Only";
            }
        }

        private void amount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                amm = Convert.ToInt32(amount.Text);
            }
            catch
            {
                label10.Text = "Please Enter Ammount in Digits Only";
            }
        }

        private void progressBar1_Click_1(object sender, EventArgs e)
        {

        }
        int a;
        string pro;
        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Increment(1);
            pro = Convert.ToString(progressBar1.Value);
            a = Convert.ToInt32(pro);
            if (a == 1)
            {
                label1.Text = "Processing, Please Wait";
            }
            if (a == 100)
            {
                label6.Show();
            }
            
        }

        private void confirmbox_Enter(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ms.Show();
        }
    }
}
