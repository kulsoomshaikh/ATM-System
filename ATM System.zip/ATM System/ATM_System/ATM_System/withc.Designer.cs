﻿namespace ATM_System
{
    partial class withc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cash1k = new System.Windows.Forms.Button();
            this.cash5k = new System.Windows.Forms.Button();
            this.cash10k = new System.Windows.Forms.Button();
            this.manual = new System.Windows.Forms.Button();
            this.wclabel = new System.Windows.Forms.Label();
            this.proc = new System.Windows.Forms.Button();
            this.warn = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.x = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // cash1k
            // 
            this.cash1k.Location = new System.Drawing.Point(13, 153);
            this.cash1k.Name = "cash1k";
            this.cash1k.Size = new System.Drawing.Size(202, 84);
            this.cash1k.TabIndex = 0;
            this.cash1k.Text = "1000";
            this.cash1k.UseVisualStyleBackColor = true;
            this.cash1k.Click += new System.EventHandler(this.cash1k_Click);
            // 
            // cash5k
            // 
            this.cash5k.Location = new System.Drawing.Point(586, 153);
            this.cash5k.Name = "cash5k";
            this.cash5k.Size = new System.Drawing.Size(202, 84);
            this.cash5k.TabIndex = 1;
            this.cash5k.Text = "5000";
            this.cash5k.UseVisualStyleBackColor = true;
            this.cash5k.Click += new System.EventHandler(this.cash5k_Click);
            // 
            // cash10k
            // 
            this.cash10k.Location = new System.Drawing.Point(12, 284);
            this.cash10k.Name = "cash10k";
            this.cash10k.Size = new System.Drawing.Size(202, 84);
            this.cash10k.TabIndex = 2;
            this.cash10k.Text = "10,000";
            this.cash10k.UseVisualStyleBackColor = true;
            this.cash10k.Click += new System.EventHandler(this.cash10k_Click);
            // 
            // manual
            // 
            this.manual.Location = new System.Drawing.Point(586, 284);
            this.manual.Name = "manual";
            this.manual.Size = new System.Drawing.Size(202, 84);
            this.manual.TabIndex = 3;
            this.manual.Text = "Input Amount Manually";
            this.manual.UseVisualStyleBackColor = true;
            this.manual.Click += new System.EventHandler(this.manual_Click);
            // 
            // wclabel
            // 
            this.wclabel.AutoSize = true;
            this.wclabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wclabel.Location = new System.Drawing.Point(180, 125);
            this.wclabel.Name = "wclabel";
            this.wclabel.Size = new System.Drawing.Size(442, 25);
            this.wclabel.TabIndex = 5;
            this.wclabel.Text = "Please Enter The Amount You Wish To Withdraw";
            // 
            // proc
            // 
            this.proc.Location = new System.Drawing.Point(342, 243);
            this.proc.Name = "proc";
            this.proc.Size = new System.Drawing.Size(103, 30);
            this.proc.TabIndex = 6;
            this.proc.Text = "Proceed";
            this.proc.UseVisualStyleBackColor = true;
            this.proc.Click += new System.EventHandler(this.proc_Click);
            // 
            // warn
            // 
            this.warn.AutoSize = true;
            this.warn.ForeColor = System.Drawing.Color.Red;
            this.warn.Location = new System.Drawing.Point(267, 175);
            this.warn.Name = "warn";
            this.warn.Size = new System.Drawing.Size(0, 17);
            this.warn.TabIndex = 7;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(310, 195);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(166, 42);
            this.textBox1.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LimeGreen;
            this.label1.Location = new System.Drawing.Point(216, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 58);
            this.label1.TabIndex = 9;
            this.label1.Text = "Withdrawn Process Succesfull\r\nPlease Take Out Your Cash";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(244, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(318, 58);
            this.label2.TabIndex = 10;
            this.label2.Text = "Withdrawn Process Failed\r\nInsufficient Balance!";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // x
            // 
            this.x.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x.Location = new System.Drawing.Point(751, 12);
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(37, 40);
            this.x.TabIndex = 12;
            this.x.Text = "X";
            this.x.UseVisualStyleBackColor = true;
            this.x.Click += new System.EventHandler(this.x_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.Black;
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkColor = System.Drawing.Color.Black;
            this.linkLabel1.Location = new System.Drawing.Point(9, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(101, 17);
            this.linkLabel1.TabIndex = 22;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "< Back to Main";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.Black;
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // withc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.x);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.warn);
            this.Controls.Add(this.proc);
            this.Controls.Add(this.wclabel);
            this.Controls.Add(this.manual);
            this.Controls.Add(this.cash10k);
            this.Controls.Add(this.cash5k);
            this.Controls.Add(this.cash1k);
            this.Name = "withc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Withdraw Cash";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cash1k;
        private System.Windows.Forms.Button cash5k;
        private System.Windows.Forms.Button cash10k;
        private System.Windows.Forms.Button manual;
        public System.Windows.Forms.Label wclabel;
        private System.Windows.Forms.Label warn;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Button proc;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button x;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}