﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_System
{
    public partial class withc : Form
    {
        public withc()
        {
            InitializeComponent();
        }
        mainscreen ms = new mainscreen();
        public int wcamount,i=0;

        private void manual_Click(object sender, EventArgs e)
        {
            cash1k.Hide();
            cash5k.Hide();
            cash10k.Hide();
            manual.Hide();
            wclabel.Show();
            textBox1.Show();
            proc.Show();
        }

        private void cash10k_Click(object sender, EventArgs e)
        {
            cash1k.Hide();
            cash5k.Hide();
            cash10k.Hide();
            manual.Hide();
            wcamount = 10000;
            if (wcamount <= ms.abalance)
            {
                ms.abalance -= wcamount;
                label1.Show();
                label2.Hide();
            }
            else
            {
                label2.Show();
                label1.Hide();
            }
        }

        private void cash5k_Click(object sender, EventArgs e)
        {
            cash1k.Hide();
            cash5k.Hide();
            cash10k.Hide();
            manual.Hide();
            wcamount = 5000;
            if (wcamount <= ms.abalance)
            {
                ms.abalance -= wcamount;
                label1.Show();
                label2.Hide();
            }
            else
            {
                label2.Show();
                label1.Hide();
            }
        }

        private void cash1k_Click(object sender, EventArgs e)
        {
            cash1k.Hide();
            cash5k.Hide();
            cash10k.Hide();
            manual.Hide();
            wcamount = 1000;
            if (wcamount <= ms.abalance)
            {
                ms.abalance -= wcamount;
                label1.Show();
                label2.Show();
                label2.Text = Convert.ToString(ms.abalance);
                i++;
            }
            else
            {
                label2.Show();
                label1.Hide();
            }
        }

        private void proc_Click(object sender, EventArgs e)
        {
            try
            {
               
                wcamount = Convert.ToInt32(textBox1.Text);
                warn.Text = " ";
                if (wcamount <= ms.abalance)
                {
                    ms.abalance -= wcamount;

                    label1.Show();
                    label2.Hide();
                }
                else
                {
                    label2.Show();
                    label1.Hide();
                }
            }
            catch
            {
                warn.Text = "Please Enter Amount In Numbers Only";
            }
        }

        private void wcm_TextChanged(object sender, EventArgs e)
        {

        }

        private void x_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ms.Show();
            if(i==1)
            {
                double sum = 0; 
                sum =  ms.abalance - 1000;  
            }
            
            
        }
    }
}
